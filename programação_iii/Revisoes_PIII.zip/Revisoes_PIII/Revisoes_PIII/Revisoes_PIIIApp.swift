//
//  Revisoes_PIIIApp.swift
//  Revisoes_PIII
//
//  Created by João Monge on 15/12/2021.
//

import SwiftUI

@main
struct Revisoes_PIIIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
