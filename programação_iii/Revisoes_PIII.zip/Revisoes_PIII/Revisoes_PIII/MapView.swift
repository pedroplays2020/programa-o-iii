//
//  MapView.swift
//  Revisoes_PIII
//
//  Created by João Monge on 15/12/2021.
//

import SwiftUI
import MapKit


struct MapView: View {
    @Binding var region : MKCoordinateRegion
    @Binding var selection : Int
    var body: some View {
        Map(coordinateRegion: $region).onTapGesture( perform: {
            self.selection = 2
        })
    }
}


