//
//  ContentView.swift
//  Revisoes_PIII
//
//  Created by João Monge on 15/12/2021.
//

import SwiftUI
import MapKit

struct ContentView: View {
    @State var selection : Int = 1
    @State var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 38.7685, longitude: -9.16), span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5))
    
    var body: some View {
        TabView(selection: $selection,
                content:  {
                    MapView(region: $region, selection: $selection).tabItem {
                        Text("Map")
                        Image(systemName: "map.fill")
                    }.tag(1)
                    WeatherView(region: $region).tabItem {
                        Text("Weather")
                        Image(systemName: "thermometer")
                    }.tag(2)
                    
                })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
