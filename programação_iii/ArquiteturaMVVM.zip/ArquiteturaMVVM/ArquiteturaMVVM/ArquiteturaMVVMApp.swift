//
//  ArquiteturaMVVMApp.swift
//  ArquiteturaMVVM
//
//  Created by aluno_istec on 16/11/2021.
//

import SwiftUI

@main
struct ArquiteturaMVVMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
