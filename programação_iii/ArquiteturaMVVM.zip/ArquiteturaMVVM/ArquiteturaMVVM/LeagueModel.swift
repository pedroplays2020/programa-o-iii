//
//  LeagueModel.swift
//  ArquiteturaMVVM
//
//  Created by aluno_istec on 16/11/2021.
//

import Foundation

// Respeitar a estrutura do json

struct League : Codable,Identifiable {
    var id : UUID? = UUID()
    let name : String
    let matches : [GameResult]
}

struct GameResult : Codable,Identifiable {
    var id : UUID? = UUID()
    let round: String
    let date:  String
    let team1: String
    let team2: String
    let score: Score?
}

struct Score : Codable,Identifiable{
    var id : UUID? = UUID()
    let ft : [Int]
}
