//
//  ContentView.swift
//  ArquiteturaMVVM
//
//  Created by aluno_istec on 16/11/2021.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        LeagueView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
